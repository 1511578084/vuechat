import { Component } from '@angular/core';

@Component({
  selector: 'page-robot',
  templateUrl: 'robot.html',
})
export class RobotPage {

  constructor() {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RobotPage');
  }

}
