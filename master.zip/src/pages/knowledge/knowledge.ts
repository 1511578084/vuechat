import { Component } from '@angular/core';

@Component({
  selector: 'page-knowledge',
  templateUrl: 'knowledge.html',
})
export class KnowledgePage {

  constructor() {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad KnowledgePage');
  }

}
