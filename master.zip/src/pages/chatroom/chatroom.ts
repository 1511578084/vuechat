import { Component } from '@angular/core';


@Component({
  selector: 'page-chatroom',
  templateUrl: 'chatroom.html',
})
export class ChatroomPage {

  constructor() {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChatroomPage');
  }

}
