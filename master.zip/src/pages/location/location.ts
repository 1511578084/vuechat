import { Component } from '@angular/core';

@Component({
  selector: 'page-location',
  templateUrl: 'location.html',
})
export class LocationPage {

  constructor() {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LocationPage');
  }

}
